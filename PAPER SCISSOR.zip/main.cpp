// AUTHOR : OWUSU ENOCK
// INEDX:UEB3268922
// CLASS: IT.A CLASS


#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main() {
    srand(time(0)); // Seed the random number generator with the current time

    char choice;
    int playerChoice, computerChoice;

    cout << "Welcome to Rock-Paper-Scissors game!" << endl;
    cout << "Enter 'r' for Rock, 'p' for Paper, or 's' for Scissors: ";
    cin >> choice;

    // Convert player's choice to an integer: 0 for Rock, 1 for Paper, 2 for Scissors
    if (choice == 'r' || choice == 'R') {
        playerChoice = 0;
    } else if (choice == 'p' || choice == 'P') {
        playerChoice = 1;
    } else if (choice == 's' || choice == 'S') {
        playerChoice = 2;
    } else {
        cout << "Invalid choice. Exiting the game." << endl;
        return 1;
    }

    computerChoice = rand() % 3; // Generate a random number between 0 and 2

    cout << "Computer chose ";
    switch (computerChoice) {
        case 0:
            cout << "Rock." << endl;
            break;
        case 1:
            cout << "Paper." << endl;
            break;
        case 2:
            cout << "Scissors." << endl;
            break;
    }

    cout << "You chose ";
    switch (playerChoice) {
        case 0:
            cout << "Rock." << endl;
            break;
        case 1:
            cout << "Paper." << endl;
            break;
        case 2:
            cout << "Scissors." << endl;
            break;
    }

    // Determine the winner
    if (playerChoice == computerChoice) {
        cout << "It's a tie!" << endl;
    } else if ((playerChoice == 0 && computerChoice == 2) ||
               (playerChoice == 1 && computerChoice == 0) ||
               (playerChoice == 2 && computerChoice == 1)) {
        cout << "You win!" << endl;
    } else {
        cout << "Computer wins!" << endl;
    }

    return 0;
}

